#ifndef CLASSTYPE_H
#define CLASSTYPE_H

enum class ClassType{
    EvCar_TYPE,
    ICECar_TYPE
};

#endif // CLASSTYPE_H
