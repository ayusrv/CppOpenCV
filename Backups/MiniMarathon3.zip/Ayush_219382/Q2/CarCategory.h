#ifndef CARCATEGORY_H
#define CARCATEGORY_H

enum class Category{
    COMMUTE,
    SPORTS,
    TOURIST
};

#endif // CARCATEGORY_H
