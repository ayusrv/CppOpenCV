#ifndef BREAKINGSYSTEM_H
#define BREAKINGSYSTEM_H

enum class BreakingSystem{
    ABS,
    TRADITIONAL
};

#endif // BREAKINGSYSTEM_H
