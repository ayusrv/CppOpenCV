#ifndef CARTYPE_H
#define CARTYPE_H

enum class CarType{
    COMMUTE,
    COMERCIAL,
    TRANSPORT
};

#endif // CARTYPE_H