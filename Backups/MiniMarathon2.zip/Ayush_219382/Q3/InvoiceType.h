#ifndef INVOICETYPE_H
#define INVOICETYPE_H

enum class InvoiceType{
    E_BILL,
    PAPER_SLIP,
    SMS_GENERATED
};

#endif // INVOICETYPE_H