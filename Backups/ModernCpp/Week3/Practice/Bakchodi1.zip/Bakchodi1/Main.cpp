#include "Functionalities.h"
#include <array>

using TArr = std::array<std::thread, 4>;
using FArr = std::array<FReturn, 3>;

int main()
{
    VehicleType data;
    TArr th;
    FArr fn;
    CreateObject(data);
    fn[1] = DisplayObject;
    fn[2] = UnCommonData;
    fn[3] = CommonData;

    for(int i=0;i<3;i++){
        th[i] = std::thread(fn[i+1], std::ref(data));
    }
    for(int i=0;i<3;i++)
    {
        if(th[i].joinable())
        {
            th[i].join();
        }
    }
}