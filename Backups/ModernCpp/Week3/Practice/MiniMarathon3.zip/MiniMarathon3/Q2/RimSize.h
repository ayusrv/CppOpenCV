#ifndef RIMSIZE_H
#define RIMSIZE_H

enum class RimSize{
    INCH_14,
    INCH_15,
    INCH_16,
    INCH_18
};

#endif // RIMSIZE_H
