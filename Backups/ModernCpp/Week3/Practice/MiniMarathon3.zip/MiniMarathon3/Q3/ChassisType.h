#ifndef CHASSISTYPE_H
#define CHASSISTYPE_H

enum class ChassisType{
    LADDER,
    TUBULAR
};

#endif // CHASSISTYPE_H
