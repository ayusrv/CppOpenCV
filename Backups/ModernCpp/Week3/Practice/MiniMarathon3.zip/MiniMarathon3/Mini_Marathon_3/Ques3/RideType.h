#ifndef RIDETYPE_H
#define RIDETYPE_H

enum class RideType
{
    RENT,
    OUTSTATION,
    LOCAL
};

#endif // RIDETYPE_H
