#ifndef DRIVERRATING_H
#define DRIVERRATING_H

enum class DriverRating{
    STAR_1,
    STAR_2,
    STAR_3
};

#endif // DRIVERRATING_H