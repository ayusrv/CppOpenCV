#ifndef ENGINETYPE_H
#define ENGINETYPE_H

enum class EngineType{
    TURBOCHARGE,
    REGULAR
};

#endif // ENGINETYPE_H
