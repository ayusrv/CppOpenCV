#ifndef ENGINECYLINDER_H
#define ENGINECYLINDER_H

enum class EngineCylinder{
    CYLINDER_4,
    CYLINDER_6
};

#endif // ENGINECYLINDER_H
