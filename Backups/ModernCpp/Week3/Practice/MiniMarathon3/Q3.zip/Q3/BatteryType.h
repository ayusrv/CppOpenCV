#ifndef BATTERYTYPE_H
#define BATTERYTYPE_H

enum class BatteryType{
    NI_CAD,
    LI_ION
};

#endif // BATTERYTYPE_H
