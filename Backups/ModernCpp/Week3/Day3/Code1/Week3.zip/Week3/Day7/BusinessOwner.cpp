#include "BusinessOwner.h"
std::ostream &operator<<(std::ostream &os, const BusinessOwner &rhs) {
    os << "_expense: " << rhs._expense
       << " _revenue: " << rhs._revenue
       << " _registeredBusinessName: " << rhs._registeredBusinessName
       << " _type: " <<static_cast<int> (rhs._Btype);
    return os;
}
BusinessOwner::BusinessOwner(float expense, float revenue, std::string registerBusinessName, BusinessOwnerType Btype)
: _expense(expense), _revenue(revenue), _registeredBusinessName(registerBusinessName), _Btype(Btype)
{
}
