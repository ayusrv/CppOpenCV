#include<iostream>
#include"Functionalities.h"
#include<thread>
#include<array>

int main(){
  
  Container data;

  std::array<std::thread,3> arr;
  
  arr[0]= std::thread (CreateObjects, std::ref(data));

  arr[0].join();

 arr[1] = std::thread (CalculateTaxPayable, std::ref(data));

  arr[2] = std::thread (CallParenOperator, std::ref(data));

  for(std::thread& th : arr){
    if(th.joinable()){
        th.join();
    }
  }


//    t2.join();

//    t3.join();

 // CalculateTaxPayable(data);


}