#include<iostream>
#include<array>
//tuple
//array
/*
   _id,_salary,_gender = {101,70000,0}

*/
int main(){
    std::array<int, 3> arr{101, 70000, 0};

    /*
        AAM ZINDAGI
    */

   int id = arr[0];
   int salary =arr[1];
   int gender = arr[2];

   /*
      MENTOS ZINDAGI
   
   */

  auto [_id, _salary, _gender] = arr;

}