#include "Employee.h"
std::ostream &operator<<(std::ostream &os, const Employee &rhs) {
    os << "_name: " << rhs._name
       << " _type: " << static_cast<int>(rhs._type)
       << " _salary: " <<  (rhs._salary);
    return os;
}
Employee::Employee(std::string name, EmployeeType Etype, float salary)
: _name(name),_type(Etype), _salary(salary)
{
}
