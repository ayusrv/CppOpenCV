#ifndef BUSINESSOWNER_H
#define BUSINESSOWNER_H
#include<iostream>
#include"BusinessOwnerType.h"
class BusinessOwner
{
private:
    float _expense;
    float _revenue;
    std::string _registeredBusinessName;
    BusinessOwnerType _Btype;
public:
    BusinessOwner(float expense, float revenue, std::string registerBusinessName, BusinessOwnerType Btype);
    BusinessOwner() = default;
    BusinessOwner(const BusinessOwner&) = delete;
    BusinessOwner(BusinessOwner&&) = delete;
    BusinessOwner &operator=(const BusinessOwner &) = delete;
    BusinessOwner &operator=(BusinessOwner &&) = delete;
    ~BusinessOwner() = default;

    float expense() const { return _expense; }

    float revenue() const { return _revenue; }

    std::string registeredBusinessName() const { return _registeredBusinessName; }

    BusinessOwnerType btype() const { return _Btype; }



    friend std::ostream &operator<<(std::ostream &os, const BusinessOwner &rhs);
};


#endif // BUSINESSOWNER_H
