#ifndef DATAMODELLER_H
#define DATAMODELLER_H


#include"Employee.h"
#include"BusinessOwner.h"
#include<variant>
#include<memory>
#include<vector>
#include <ostream>

using BusinessPointer = std::unique_ptr<BusinessOwner>;
using EmpPointer = std::unique_ptr<Employee>;
using VType = std::variant<BusinessPointer,EmpPointer>;

class DataModeller
{
private:
    VType _instance; //instance inside DataModeller
    std::vector<float> _goodsPrices; 
public:
    DataModeller(VType v, std::vector<float> prices);
    void operator()();
    DataModeller() = delete;
    DataModeller(const DataModeller&) = delete;
    DataModeller(DataModeller&) = delete;
    DataModeller &operator=(const DataModeller &) = delete;
    DataModeller &operator=(DataModeller &&) = delete;
    ~DataModeller() = default;


   const VType& instance() const { return _instance; }

    std::vector<float> goodsPrices() const { return _goodsPrices; }

    friend std::ostream &operator<<(std::ostream &os, const DataModeller &rhs);

    
};

#endif // DATAMODELLER_H
