#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include"DataModeller.h"
#include<memory>
#include<optional>
using dataPointer = std::unique_ptr< DataModeller >;
using Container = std::vector <dataPointer>;

void CreateObjects(Container &data);

void CalculateTaxPayable(const Container &data);

void CallParenOperator(const Container &data);

// std::optional<Container>FindEmployeeDataModeller(const Container &data);

#endif // FUNCTIONALITIES_H
