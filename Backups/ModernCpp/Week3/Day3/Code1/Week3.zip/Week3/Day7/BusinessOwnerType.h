#ifndef BUSINESSTYPE_H
#define BUSINESSTYPE_H

enum class BusinessOwnerType{
      SME,
      MNC
};

#endif // BUSINESSTYPE_H
