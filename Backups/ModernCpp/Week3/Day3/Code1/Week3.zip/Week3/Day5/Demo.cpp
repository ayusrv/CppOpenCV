#include<iostream>

class Demo
{
private:
     int _id;
public:
    Demo() = default;
    Demo(Demo &&) = default;//move constructor(rvalue)
    Demo (int id) : _id(id) {}
    Demo(const Demo &) {std::cout<<"Copy constructor called \n";} //copy constructor
    Demo &operator=(Demo &&) = default; //move assignment (rvalue)
    Demo &operator=(const Demo &) = default;//assignment operator overload
    ~Demo() =default;

    friend std::ostream &operator<<(std::ostream &os, const Demo &rhs){
        os<<"-id"<<rhs._id;
        return os;
    }
};


Demo Magic(Demo& obj){
    Demo temp(obj);
 //   std::cout<<"Address of temp is : "<<&temp <<"\n";
    return temp;
}

int main(){
    Demo obj(100);
 //   std::cout<<"Address of obj is :"<<&obj<<"\n";
    Demo return_obj =Magic(obj);
 //   std::cout<<"Adress of return_obj is :"<<&return_obj<<"\n";
}

///Terminal command :g++ -g Demo.cpp -fno-elide-constructors -o app



///home/kpit/.ssh/id_rsa.pub