/*
   Create a thread t1 that calculates square of all numbers 
   in an array and store in aresult container
*/

#include<iostream>
#include<array>
#include<thread>



int main(){
    std::array<int, 5> result{1,2,3,4,5};
    std::array<int,5>res;
    /* 
     create an instance t1
    */

   std::thread t1(
    [&res](std::array<int,5>& data){
        int k=0;
        for(int val : data){
            res[k++] = val*val;
        }
    },
    std::ref(res)
   );

   /*
    wait for t1
    
    */

   t1.join();

   /*
      display output
   */
  auto itr = res.begin();

  for(int val : result){
     if(itr != res.end()){
    std::cout<<"Square of "<<*itr<<" is = "<<val<<"\n";
    itr++;
  }
}
}