/*
   Create an array of 5 threads that calculate the square
   of ONE NUMBER from an array of 5 integers. Store answer in a result container
*/

#include<iostream>
#include<thread>
#include<iostream>
#include<functional>

void InstantiateThreads( std::array<std::thread, 5>& threadArr,
  std::function<void(int,int) > f1,
   std::array<int, 5> data
   )
  {
  auto itr = data.begin();

    //for(std::thread& t : threadArr)
    for(int i=0;i<5;i++) {
           threadArr[i]= std::thread(f1,*itr++,i);
    }
    
}

void JoinThreads(std::array<std::thread, 5>& threadArr){

    for(std::thread& t : threadArr){
        if(t.joinable()){
            t.join();
        }
    }
}
void DisplayResult(std::array<int, 5>&result,std::array<int,5>& data){

      auto itr1 = data.begin();

    for(int val : result){
        if(itr1 != data.end()){
            std::cout<<" Square of " << *itr1 <<" is "<<val<<"\n";
            itr1++;
        }
    }
}
void StartApp(){

    std::array<int, 5> data{ 10,20, 30 ,40 ,50};
    std::array<int, 5> result;


    auto f1 = [&](int number,int i) {result[i] = number * number; };
    
    std::array<std::thread , 5> threadArr;

    InstantiateThreads( threadArr,f1,data);
    JoinThreads(threadArr);
    DisplayResult(result,data);
}

int main(){
 
  StartApp();
   

   
}