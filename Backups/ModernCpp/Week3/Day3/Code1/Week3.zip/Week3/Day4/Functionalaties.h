#ifndef FUNCTIONALATIES_H
#define FUNCTIONALATIES_H

#include <list>
#include <memory>
#include <optional>
#include <functional>
#include <variant>
#include "VehicleType.h"
#include "Bike.h"
#include "CarClass.h"

using BikePointer = std::shared_ptr<Bike>;
using CarPointer = std::shared_ptr<Car> ;
using VType = std::variant<BikePointer , CarPointer>;
using Container = std::list<VType>;

/*
* Taking an empty container by lvalue reference and fill it with variant objects

* It should return void

*/

void CreateObjects(Container& data);

float AveragePrice(const Container& data);

VType InstanceWithMinimumPrice(const Container& data);

/*
    Check if given ID is present in any of the instance

*/
bool IfIdExists(const Container& data, std::string id);

/*
   Return all instance whose type matches with type passed
*/
std::optional<std::list<VType>> InstanceWithMatchingType(const Container& data, VehicleType type);




#endif // FUNCTIONALATIES_H
