#include "CarClass.h"

Car::Car(std::string id, float price, VehicleType carType)
:_id(id),_price(price),_carType(carType)
{
    
}

std::ostream &operator<<(std::ostream &os, const Car &rhs) {
    os << "_id: " << rhs._id
       << " _price: " << rhs._price
       << " _carType: " <<static_cast<int> (rhs._carType);
    return os;
}
