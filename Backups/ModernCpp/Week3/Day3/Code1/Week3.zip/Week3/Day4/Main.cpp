#include<iostream>
#include"Functionalaties.h"

int main(){

  Container data;

  CreateObjects(data);

  float Result = AveragePrice(data);
  std::cout<<Result<<"\n";

  bool IsFind = IfIdExists(data,"c101");
  std::cout<<IsFind<<"\n";
  
  auto ans = InstanceWithMatchingType(data,VehicleType::SEDAN);

  ans.value();
  if(ans.has_value()){ 
for(const auto& ptr : ans.value()){
        std::visit(
            [&](auto &&val){
                std::cout<<*val<<"\n";
            },
            ptr
        );
    }
  }
}