
#ifndef CARTYPE_H
#define CARTYPE_H

enum class VehicleType{
    SEDAN,
    SUV,
    HATCHBACK,
    COMMUTE,
    SPORTS
};

#endif // CARTYPE_H
