
#ifndef CARCLASS_H
#define CARCLASS_H

#include <iostream>
#include <memory>
#include "VehicleType.h"

class Car
{
private:
    std::string _id;
    float _price;
    VehicleType _carType;
public:
    Car() = default;
    Car(Car &&) = default;
    Car(const Car &) = default;   
    Car &operator=(Car &&) = default;
    Car &operator=(const Car &) = default;
   ~Car() = default;

   std::string id() const { return _id; }

   float price() const { return _price; }

   VehicleType type() const { return _carType; }

   Car(std::string id, float price, VehicleType carType);

   friend std::ostream &operator<<(std::ostream &os, const Car &rhs);
};


#endif // CARCLASS_H
