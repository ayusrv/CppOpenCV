#include<iostream>
#include<mutex>
#include<thread>
#include<array>

std::mutex mt;

void CalculateSquare(std::array<int, 3>& arr){
    for(int val : arr){
        std::lock_guard<std::mutex> lk(mt);
        std::cout<<val*val<<"\n";

    }
}

int main(){
    std::array<int, 3> ar{1,2,3};
    std::thread t1 (CalculateSquare , std::ref(ar));
    t1.join();
    std::thread t2 (CalculateSquare , std::ref(ar));
    t2.join();
}