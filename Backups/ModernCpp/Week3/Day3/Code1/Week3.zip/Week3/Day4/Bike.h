#ifndef CAR_H
#define CAR_H

#include<iostream>
#include<memory>
#include"VehicleType.h"
class Bike
{
private:
    std::string _id;
    float _price;
    VehicleType _bikeType;
public:
    Bike() = default;
    Bike(Bike &&) = default;
    Bike(const Bike &) = default;   
    Bike &operator=(Bike &&) = default;
    Bike &operator=(const Bike &) = default;
   ~Bike() {}


   Bike(std::string id, float price, VehicleType bikeType);

   std::string id() const { return _id; }

   float price() const { return _price; }

   VehicleType type() const { return _bikeType; }

   friend std::ostream &operator<<(std::ostream &os, const Bike &rhs);


};

#endif // CAR_H
