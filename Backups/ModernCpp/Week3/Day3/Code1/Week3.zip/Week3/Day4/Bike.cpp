#include "Bike.h"

Bike::Bike(std::string id, float price, VehicleType bikeType)
:_id(id),_price(price),_bikeType(bikeType)
{
}
std::ostream &operator<<(std::ostream &os, const Bike &rhs) {
    os << "_id: " << rhs._id
       << " _price: " << rhs._price
       << " _bikeType: " <<static_cast<int> (rhs._bikeType);
    return os;
}
