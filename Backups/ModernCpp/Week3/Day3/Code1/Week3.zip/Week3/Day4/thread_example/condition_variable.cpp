#include <condition_variable>
#include <iostream>
#include <thread>

/*
    DisplaySquare : It should print of number
    received as input from the user

    Main:
         -Main will take cin input and store value in a global variable
*/

int number = 0;
std::condition_variable cv;
bool flag = false;
std::mutex mt;

void Square()
{
    // condition check : each time t1 thread is scheduled ,
    // condition must be checked
    std::unique_lock<std::mutex> ul(mt);
    cv.wait(ul, []()
            { return flag; });
    std::cout << "Square of " << number << " is " << number * number << "\n";
}

int main()
{
    /// Step 1 : thread is registered (instantiated and handed over to OS)
    std::thread t1(&Square);

    // step 2(a) : user input arrives(this can take a very long time)
    std::cin >> number;

    // step 2(b) : set the flag true
    flag = true; // this specifies condition is met

    // step 3: send a signal
    cv.notify_one(); // signal sent from main to OS that we can now invoke
                     //  the waiting thread

    t1.join();
}