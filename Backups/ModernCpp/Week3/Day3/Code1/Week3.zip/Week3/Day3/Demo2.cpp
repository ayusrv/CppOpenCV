#include<vector>
#include<iostream>
#include<optional>



    void TakeInput(std::vector<int>& data, int N){
        int val = -1;
//std::cout<<"Enter "<<N<<" "<< " Values = ";
        for(int i=0;i<N;i++){
            std::cin>>val;

            data[i] = val;
        }
    }

    /*
        Identify even numbers from data. Store all of them in 
        result . Return result

        scenario 1: There is at least 1 even number in data.
                     You identify the number/s.store in result

        scenario 2: data is empty. Handle by raising execption

        scenario 3: data is empty. However,all number are odd
    */

      //ReturnEvenNumbers MAY OR MAY NOT RETUEN A VALUE
      //A vector of integer as a return  value from this function is OPTIONAL
      
      std::optional<std::vector<int>> ReturnEvenNumbers(std::vector<int>& data){

            if(data.empty()){
                throw std::runtime_error("Error as data is empty");
            }

            std::vector<int> result;

            for(int v : data){
                if(v % 2 ==0){
                    result.push_back(v);
                }
            }
          
          if(result.empty()){
            return std::nullopt;//nullopt is symbol to indicate no value
          }

          return result;

        }
    
int main(){
    int N = -1;
    
   //std::cout<<"Enter the number of elements = "; 
   std::cin>>N;

   std::vector<int> v1(N); //space for N integer is now reserved on the heap
  //  std::vector<int>data;

    TakeInput(v1,N);

   //std::optional< std::vector<int>> even_number = ReturnEvenNumbers(data);
   std::optional< std::vector<int>> even_number = ReturnEvenNumbers(v1);
   /*
       has_value return false if optional wrapper contains nullopt
   */
   if(even_number.has_value()){
    /*
       we only come inside if when has_value return true
       i.e.valid value is present
       i.e.container of even numbers is found in optional
    
    */

    std::cout<<even_number.value().size()<<std::endl;
   }

   else{
    std::cout<<"Vector returned no values\n";
   }

}