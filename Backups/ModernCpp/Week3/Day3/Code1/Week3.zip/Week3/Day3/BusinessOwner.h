#ifndef BUSINESSOWNER_H
#define BUSINESSOWNER_H

#include<iostream>

class BusinessOwner
{
private:
    /* data */
public:
    BusinessOwner(/* args */) {}
    ~BusinessOwner() {}

    void PayTax(){
        std::cout<<"Business has to pay advance tax and GST every month/quarter"<<std::endl;
    }
};

#endif // BUSINESSOWNER_H
