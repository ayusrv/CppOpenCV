#ifndef BUSSINESSTYPE_H
#define BUSSINESSTYPE_H

enum class BussinessType{
    SME,
    MNC
};

#endif // BUSSINESSTYPE_H
