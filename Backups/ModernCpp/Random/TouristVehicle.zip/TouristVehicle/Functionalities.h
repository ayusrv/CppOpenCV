#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <vector>
#include "TouristVehicle.h"
#include "EmptyContainerException.h"
#include "SizeNotMatched.h"
#include "NullPointerException.h"
#include "WrongEnumException.h"

using PermitContainer = std::vector<std::shared_ptr<Permit>>;
using Pointer = std::shared_ptr<TouristVehicle>;
using Container = std::vector<Pointer>;

void CreateObject(Container &data, PermitContainer &data2);
Container NInstances(Container &data, PermitContainer &data2, int n);
float AverageCharge(Container &data, PermitContainer &data2, std::string type);
std::string MaximumCharge(Container &data, PermitContainer &data2);
Container FirstNInstances(Container &data, PermitContainer &data2, int n);

#endif //FUNCTIONALITIES_H