#ifndef SizeExceeded_H
#define SizeExceeded_H

#include<stdexcept>
#include<cstring>

class SizeExceeded : public std::exception
{
private:
    char* _msg;
public:
    SizeExceeded(const char* msg) {
        
        _msg = new char[strlen(msg)+1];
        strcpy(_msg,msg);

    }

    SizeExceeded() = delete;
    SizeExceeded(const SizeExceeded&) = delete;
    SizeExceeded(SizeExceeded&&) = default;
    SizeExceeded& operator = (const SizeExceeded&) = delete;
    SizeExceeded&& operator = (SizeExceeded&&) = delete;
    // ~SizeExceeded() = default;
    ~SizeExceeded() {
        delete[] _msg;
    }

    virtual const char* what() const _GLIBCXX_TXN_SAFE_DYN _GLIBCXX_NOTHROW override{
        return _msg;
    }
};

#endif // SizeExceeded_H
