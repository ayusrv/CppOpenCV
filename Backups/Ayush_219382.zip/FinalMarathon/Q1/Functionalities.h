#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<thread>
#include <mutex>
#include <array>
#include <algorithm>
#include <numeric>

#include "TransportVehicle.h"
#include "EmptyContainerException.h"
#include "SizeExceeded.h"
#include "EnumNotMatch.h"
#include "WrongMonth.h"

using TransportPointer = std::shared_ptr<TransportVehicle>;
using Container = std::array<TransportPointer, 4>;

void CreateObjects(Container& data);
void DisplayObject(Container& data, int n);
void Average(Container& data, VehicleType type);
void SameType(Container& data);


#endif // FUNCTIONALITIES_H
