#include "Functionalities.h"

int main()
{
    Container data;

    //Creting the threads
    std::thread t1(&CreateObjects, std::ref(data));
    std::thread t2(&DisplayObject, std::ref(data), 3);
    std::thread t3(&Average, std::ref(data), VehicleType::BUS);
    std::thread t4(&SameType, std::ref(data));

    //Try catch block
    try
    {
        if(t1.joinable())
            t1.join();
        if(t2.joinable())
            t2.join();
        if(t3.joinable())
            t3.join();
        if(t4.joinable())
            t4.join();
    }
    catch(EmptyContainerException& ex)
    {
        std::cout<<ex.what();
    }
    catch(EnumNotMatch& ex)
    {
        std::cout<<ex.what();
    }
    catch(SizeExceeded& ex)
    {
        std::cout<<ex.what();
    }
    catch(WrongMonth& ex)
    {
        std::cout<<ex.what();
    }
}