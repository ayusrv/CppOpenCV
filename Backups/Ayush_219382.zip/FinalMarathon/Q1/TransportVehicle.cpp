#include "TransportVehicle.h"
std::ostream &operator<<(std::ostream &os, const TransportVehicle &rhs) {
    os << "_permit: " << *rhs._permit
       << " _vehicle_type: " ;
    if(rhs._vehicle_type == VehicleType::BUS) os<<"Bus ";
    else if(rhs._vehicle_type == VehicleType::CAB) os<<"Cab ";
    else if(rhs._vehicle_type == VehicleType::MINI_VAN) os<<"Mini Van ";
    os   << " _seat_count: " << rhs._seat_count
       << " _stops_count: " << rhs._stops_count;
    return os;
}

TransportVehicle::TransportVehicle(std::shared_ptr<Permit> permit, VehicleType vehicle_type, unsigned int seat_count, unsigned int stops_count)
                : _permit{permit}, _vehicle_type{vehicle_type}, _seat_count{seat_count}, _stops_count{stops_count} {}