#ifndef WrongMonth_H
#define WrongMonth_H

#include<stdexcept>
#include<cstring>

class WrongMonth : public std::exception
{
private:
    char* _msg;
public:
    WrongMonth(const char* msg) {
        
        _msg = new char[strlen(msg)+1];
        strcpy(_msg,msg);

    }

    WrongMonth() = delete;
    WrongMonth(const WrongMonth&) = delete;
    WrongMonth(WrongMonth&&) = default;
    WrongMonth& operator = (const WrongMonth&) = delete;
    WrongMonth&& operator = (WrongMonth&&) = delete;
    // ~WrongMonth() = default;
    ~WrongMonth() {
        delete[] _msg;
    }

    virtual const char* what() const _GLIBCXX_TXN_SAFE_DYN _GLIBCXX_NOTHROW override{
        return _msg;
    }
};

#endif // WrongMonth_H
