#include "Functionalities.h"
std::mutex mt;

//Creating the objects
void CreateObjects(Container& data)
{
    data[0] = std::make_shared<TransportVehicle>(std::make_shared<Permit>("12A", 10), VehicleType::BUS, 3, 3);
    data[1] = std::make_shared<TransportVehicle>(std::make_shared<Permit>("13A", 9), VehicleType::BUS, 4, 2);
    data[2] = std::make_shared<TransportVehicle>(std::make_shared<Permit>("14A", 8), VehicleType::BUS, 5, 4);
    data[3] = std::make_shared<TransportVehicle>(std::make_shared<Permit>("15A", 7), VehicleType::BUS, 6, 5);
}

//Displaying the objects
void DisplayObject(Container& data, int n)
{

    //Cheking the empty container
    if(data.empty())
    {
        throw EmptyContainerException("Conatiner is empty");
    }

    //Cheking the size of the data
    if(n<0 || n>data.size())
    {
        throw SizeExceeded("Size you have provided is exceeded");
    }

    //Printing the data
    for(TransportPointer tp : data)
    {

        //Cheking the worng month exception
        if(tp->permit()->permitDurationRemaining()>12 && tp->permit()->permitDurationRemaining()<=0)
        {
            throw WrongMonth("Month is invalid");
        }
        std::lock_guard<std::mutex> lg(mt);
        std::cout<<*tp<<std::endl;
    }
}

//Calculating the average
void Average(Container& data, VehicleType type)
{

    //Checking the empty conatiner
    if(data.empty())
    {
        throw EmptyContainerException("Data is empty");
    }

    //Cheking the enum
    if(type!= VehicleType::BUS && type!= VehicleType::CAB && type!= VehicleType::MINI_VAN)
    {
        throw EnumNotMatch("Wrong Enum provided");
    }
    
    float ans =0.0f;
    int count = 0;

    //suing accumulator to count the average
    ans = std::accumulate(
        data.begin(),
        data.end(),
        0.0f,
        [&](float start_val, const TransportPointer& tp)
        {
            float val = 0;
            if(tp->vehicleType()==type)
            {
                val = start_val+tp->seatCount();
                count++;
            }
            return val;
        }
    );
    std::lock_guard<std::mutex> lg(mt);
    std::cout<<"Average of seat count: "<<ans/count<<std::endl;
}

//Checking the type of the data
void SameType(Container& data)
{
    if(data.empty())
    {
        throw EmptyContainerException("Data is empty");
    }
    bool bus = std::all_of(
        data.begin(),
        data.end(),
        [](const TransportPointer& tp)
        {
            return tp->vehicleType()==VehicleType::BUS;
        }
    );

    bool cab = std::all_of(
        data.begin(),
        data.end(),
        [](const TransportPointer& tp)
        {
            return tp->vehicleType()==VehicleType::CAB;
        }
    );

    bool mini_van = std::all_of(
        data.begin(),
        data.end(),
        [](const TransportPointer& tp)
        {
            return tp->vehicleType()==VehicleType::MINI_VAN;
        }
    );
    std::lock_guard<std::mutex> lg(mt);
    if(bus || cab || mini_van){
        std::cout<<"Types are matched"<<std::endl;
    }else{
        std::cout<<"Types mismatched"<<std::endl;
    }
}
