#include "Permit.h"
std::ostream &operator<<(std::ostream &os, const Permit &rhs) {
    os << "_permit_number: " << rhs._permit_number
       << " _permit_duration_remaining: " << rhs._permit_duration_remaining;
    return os;
}

Permit::Permit(std::string permit_number, int permit_duration_remaining)
        : _permit_number{permit_number}, _permit_duration_remaining{permit_duration_remaining} {}