#ifndef TRANSPORTVEHICLE_H
#define TRANSPORTVEHICLE_H

#include <memory>
#include <ostream>
#include "Permit.h"
#include "VehicleType.h"
class TransportVehicle
{
private:
    std::shared_ptr<Permit> _permit;
    VehicleType _vehicle_type;
    unsigned int _seat_count;
    unsigned int _stops_count;
public:
    TransportVehicle()=default;
    TransportVehicle(const TransportVehicle &)=delete;
    TransportVehicle(TransportVehicle && )=delete;
    TransportVehicle & operator=(const TransportVehicle & )=delete;
    TransportVehicle &operator=(TransportVehicle &&)=delete;
    ~TransportVehicle()=default;
    TransportVehicle(std::shared_ptr<Permit> permit, VehicleType vehicle_type, unsigned int seat_count, unsigned int stops_count);

    std::shared_ptr<Permit> permit() const { return _permit; }
    void setPermit(const std::shared_ptr<Permit> &permit) { _permit = permit; }

    VehicleType vehicleType() const { return _vehicle_type; }
    void setVehicleType(const VehicleType &vehicle_type) { _vehicle_type = vehicle_type; }

    unsigned int seatCount() const { return _seat_count; }
    void setSeatCount(unsigned int seat_count) { _seat_count = seat_count; }

    unsigned int stopsCount() const { return _stops_count; }
    void setStopsCount(unsigned int stops_count) { _stops_count = stops_count; }

    friend std::ostream &operator<<(std::ostream &os, const TransportVehicle &rhs);
};

#endif // TRANSPORTVEHICLE_H
