#ifndef PERMIT_H
#define PERMIT_H

#include <iostream>

class Permit
{
private:
    std::string _permit_number;
    int _permit_duration_remaining;
public:
    Permit()=default;
    Permit(const Permit &)=delete;
    Permit(Permit && )=delete;
    Permit & operator=(const Permit & )=delete;
    Permit &operator=(Permit &&)=delete;
    ~Permit()=default;
    Permit(std::string permit_number, int permit_duration_remaining);

    std::string permitNumber() const { return _permit_number; }
    void setPermitNumber(const std::string &permit_number) { _permit_number = permit_number; }

    int permitDurationRemaining() const { return _permit_duration_remaining; }
    void setPermitDurationRemaining(int permit_duration_remaining) { _permit_duration_remaining = permit_duration_remaining; }

    friend std::ostream &operator<<(std::ostream &os, const Permit &rhs);
    
};

#endif // PERMIT_H
