#ifndef EnumNotMatch_H
#define EnumNotMatch_H

#include<stdexcept>
#include<cstring>

class EnumNotMatch : public std::exception
{
private:
    char* _msg;
public:
    EnumNotMatch(const char* msg) {
        
        _msg = new char[strlen(msg)+1];
        strcpy(_msg,msg);

    }

    EnumNotMatch() = delete;
    EnumNotMatch(const EnumNotMatch&) = delete;
    EnumNotMatch(EnumNotMatch&&) = default;
    EnumNotMatch& operator = (const EnumNotMatch&) = delete;
    EnumNotMatch&& operator = (EnumNotMatch&&) = delete;
    // ~EnumNotMatch() = default;
    ~EnumNotMatch() {
        delete[] _msg;
    }

    virtual const char* what() const _GLIBCXX_TXN_SAFE_DYN _GLIBCXX_NOTHROW override{
        return _msg;
    }
};

#endif // EnumNotMatch_H
