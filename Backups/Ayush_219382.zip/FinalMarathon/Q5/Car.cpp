#include "Car.h"
std::ostream &operator<<(std::ostream &os, const Car &rhs) {
    os << "_id: " << rhs._id
       << " _price: " << rhs._price
       << " _gst_amount: " << rhs._gst_amount
       << " _car_length: " << rhs._car_length
       << " _car_seat_count: " << rhs._car_seat_count;
    return os;
}

Car::Car(std::string id, CarType car_type, float price, int gst_amount, float car_length, unsigned int car_seat_count)
    : _id{id}, _car_type{car_type}, _gst_amount{gst_amount}, _car_length{car_length}, _car_seat_count{car_seat_count} {}
    