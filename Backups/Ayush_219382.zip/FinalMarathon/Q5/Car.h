#ifndef CAR_H
#define CAR_H

#include <iostream>
#include "CarType.h"

class Car{
    std::string _id;
    CarType _car_type;
    float _price;
    int _gst_amount;
    float _car_length;
    unsigned int _car_seat_count;

public:

    Car()=default;
    Car(const Car &)=default;
    Car(Car && )=default;
    Car & operator=(const Car & )=default;
    Car &operator=(Car &&)=default;
    ~Car()=default;
    Car(std::string id, CarType car_type, float price, int gst_amount, float car_length, unsigned int car_seat_count);

    std::string id() const { return _id; }
    void setId(const std::string &id) { _id = id; }

    CarType carType() const { return _car_type; }
    void setCarType(const CarType &car_type) { _car_type = car_type; }

    float price() const { return _price; }
    void setPrice(float price) { _price = price; }

    int gstAmount() const { return _gst_amount; }
    void setGstAmount(int gst_amount) { _gst_amount = gst_amount; }

    float carLength() const { return _car_length; }
    void setCarLength(float car_length) { _car_length = car_length; }

    unsigned int carSeatCount() const { return _car_seat_count; }
    void setCarSeatCount(unsigned int car_seat_count) { _car_seat_count = car_seat_count; }

    friend std::ostream &operator<<(std::ostream &os, const Car &rhs);
};

#endif // CAR_H
