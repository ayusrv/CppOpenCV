#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <vector>
#include "sizeMismatched.h"
#include "EmptyContainerException.h"
#include <bits/stdc++.h>
#include "Car.h"

using Container = std::vector<Car>;
void createObject(Container &data);
void makePriority(Container &data);


//Dsiplaying the top data
template <typename T, typename C>
void Display(std::priority_queue<T, std::vector<T>, C> &pq)
{
    std::cout << pq.top() << std::endl;
}

//Displying the car seat count
template <typename T, typename C>
void CarSeatCount(std::priority_queue<T, std::vector<T>, C> &pq)
{
    if (pq.empty())
    {
        throw EmptyContainerException("Data is empty");
    }
    Car c = pq.top();
    std::cout << "Car Seat Count: " << c.carSeatCount();
    std::cout << std::endl;
}


//Displaying the raod tax
template <typename T, typename C>
void RoadTax(std::priority_queue<T, std::vector<T>, C> &pq, std::function<void(std::priority_queue<Car, std::vector<Car>, Check> &pq)> fun)
{
    if (pq.empty())
    {
        throw EmptyContainerException("Data is empty");
    }

    fun(pq);
}

// Displying the N instances
template <typename T, typename C>
void DisplayInstance(std::priority_queue<T, std::vector<T>, C> &pq, int n)
{
    if (pq.empty())
    {
        throw EmptyContainerException("Data is empty");
    }
    if (n > pq.size())
    {
        throw SizeMismatched("Size is wrong");
    }
    while (n-- > 0)
    {
        std::cout << "Popping: " << pq.top() << std::endl;
        pq.pop();
    }
}

#endif // FUNCTIONALITIES_H
