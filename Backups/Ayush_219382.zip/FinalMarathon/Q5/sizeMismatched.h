#ifndef SizeMismatched_H
#define SizeMismatched_H

#include<stdexcept>
#include<cstring>

class SizeMismatched : public std::exception
{
private:
    char* _msg;
public:
    SizeMismatched(const char* msg) {
        
        _msg = new char[strlen(msg)+1];
        strcpy(_msg,msg);

    }

    SizeMismatched() = delete;
    SizeMismatched(const SizeMismatched&) = delete;
    SizeMismatched(SizeMismatched&&) = default;
    SizeMismatched& operator = (const SizeMismatched&) = delete;
    SizeMismatched&& operator = (SizeMismatched&&) = delete;
    // ~SizeMismatched() = default;
    ~SizeMismatched() {
        delete[] _msg;
    }

    virtual const char* what() const _GLIBCXX_TXN_SAFE_DYN _GLIBCXX_NOTHROW override{
        return _msg;
    }
};

#endif // SizeMismatched_H
