#include "Functionalities.h"

int main()
{

    Container data;
    createObject(data);
    try
    {
        makePriority(data);
    }
    catch(SizeMismatched& ex){
        std::cout<<ex.what();
    }
    catch(EmptyContainerException& ex){
        std::cout<<ex.what();
    }
}