#include "Functionalities.h"

struct Check
{
    bool operator()(Car &c1, Car &c2)
    {
        return c1.price() < c2.price();
    }
};

// Creating the object
void createObject(Container &data)
{
    data.push_back(Car("CS12", CarType::HATCHBACK, 3000, 300, 3, 4));
    data.push_back(Car("CS13", CarType::SEDAN, 4000, 400, 4, 6));
    data.push_back(Car("CS14", CarType::SUV, 5000, 500, 2, 2));
}

std::function<void(std::priority_queue<Car, std::vector<Car>, Check> &pq)> fun = [](std::priority_queue<Car, std::vector<Car>, Check> &pq) {
    float tax = 0.0f;
        Car c = pq.top();
        if (c.carType() == CarType::SEDAN)
        {
            tax = 0.14 * c.price();
        }
        else
        {
            tax = 0.1 * c.price();
        }
        std::cout << "Road Tax : " << tax << std::endl;
};

// Mkaing the priority queue
void makePriority(Container & data)
{
    if (data.empty())
    {
        throw EmptyContainerException("Data is empty");
    }
    std::priority_queue<Car, std::vector<Car>, Check> pq(data.begin(), data.end());
    Display<Car, Check>(pq);
    CarSeatCount<Car, Check>(pq);
    RoadTax<Car, Check>(pq, fun);

    DisplayInstance<Car, Check>(pq, 2);
}
