#include "ConnectedVehicle.h"

ConnectedVehicle::ConnectedVehicle(std::string vehicle_id, std::string vehicle_full_mode, SoftwareType vehicle_software_type, NormCategory vehicle_norm_category, EnginePointer vehicle_engine)
        : _vehicle_id{vehicle_id}, _vehicle_full_mode{vehicle_full_mode}, _vehicle_software_type{vehicle_software_type}, _vehicle_norm_category{vehicle_norm_category}, _vehicle_engine{vehicle_engine} {}
        
std::ostream &operator<<(std::ostream &os, const ConnectedVehicle &rhs) {
    os << "_vehicle_id: " << rhs._vehicle_id
       << " _vehicle_full_mode: " << rhs._vehicle_full_mode
       << " _vehicle_software_type: ";
       if(rhs._vehicle_software_type==SoftwareType::ADAPTIVE_AUTOSAR) os<<"Adaptive autosar ";
       else os<<"Classic autosar ";
    os  << " _vehicle_norm_category: ";
    if( rhs._vehicle_norm_category==NormCategory::BS6_IN) os<<"BS6_IN ";
    else if( rhs._vehicle_norm_category==NormCategory::EU) os<<"EU ";
    else if( rhs._vehicle_norm_category==NormCategory::GB) os<<"GB ";
    else if( rhs._vehicle_norm_category==NormCategory::US) os<<"US ";
    os  << " _vehicle_engine: " << *rhs._vehicle_engine;
    return os;
}
