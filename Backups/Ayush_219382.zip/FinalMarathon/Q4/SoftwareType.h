#ifndef SOFTWARETYPE_H
#define SOFTWARETYPE_H

enum class SoftwareType{
    CLASSIC_AUTOSAR,
    ADAPTIVE_AUTOSAR
};

#endif // SOFTWARETYPE_H