#ifndef CONNECTEDVEHICLE_H
#define CONNECTEDVEHICLE_H

#include <iostream>
#include <memory>
#include "Engine.h"
#include "SoftwareType.h"
#include "NormCategory.h"

using EnginePointer = std::shared_ptr<Engine>;

class ConnectedVehicle
{
private:
    std::string _vehicle_id;
    std::string _vehicle_full_mode;
    SoftwareType _vehicle_software_type;
    NormCategory _vehicle_norm_category;
    EnginePointer _vehicle_engine;

public:
    ConnectedVehicle()=default;
    ConnectedVehicle(const ConnectedVehicle &)=delete;
    ConnectedVehicle(ConnectedVehicle && )=delete;
    ConnectedVehicle & operator=(const ConnectedVehicle & )=delete;
    ConnectedVehicle &operator=(ConnectedVehicle &&)=delete;
    ~ConnectedVehicle()=default;
    ConnectedVehicle(std::string _vehicle_id, std::string vehicle_full_mode, SoftwareType vehicle_software_type, NormCategory vehicle_norm_category, EnginePointer vehicle_engine);

    std::string vehicleId() const { return _vehicle_id; }
    void setVehicleId(const std::string &vehicle_id) { _vehicle_id = vehicle_id; }

    std::string vehicleFullMode() const { return _vehicle_full_mode; }
    void setVehicleFullMode(const std::string &vehicle_full_mode) { _vehicle_full_mode = vehicle_full_mode; }

    SoftwareType vehicleSoftwareType() const { return _vehicle_software_type; }
    void setVehicleSoftwareType(const SoftwareType &vehicle_software_type) { _vehicle_software_type = vehicle_software_type; }

    NormCategory vehicleNormCategory() const { return _vehicle_norm_category; }
    void setVehicleNormCategory(const NormCategory &vehicle_norm_category) { _vehicle_norm_category = vehicle_norm_category; }

    EnginePointer vehicleEngine() const { return _vehicle_engine; }
    void setVehicleEngine(const EnginePointer &vehicle_engine) { _vehicle_engine = vehicle_engine; }

    friend std::ostream &operator<<(std::ostream &os, const ConnectedVehicle &rhs);
};

#endif // CONNECTEDVEHICLE_H
