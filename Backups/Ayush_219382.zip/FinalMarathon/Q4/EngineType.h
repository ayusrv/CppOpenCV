#ifndef ENGINETYPE_H
#define ENGINETYPE_H

enum class EngineType{
    IC,
    EV
};

#endif // ENGINETYPE_H
