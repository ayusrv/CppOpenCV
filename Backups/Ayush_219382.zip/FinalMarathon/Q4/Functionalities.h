#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <iostream>
#include <algorithm>
#include <numeric>
#include <vector>
#include <optional>
#include <unordered_map>
#include <vector>
#include <mutex>
#include "ConnectedVehicle.h"
#include "EmptyContainerEXception.h"

using ConnectedPointer = std::shared_ptr<ConnectedVehicle>;
using ConnectedContainer = std::vector<ConnectedPointer>;
using PairType = std::pair<std::string, ConnectedPointer>;
using Container = std::unordered_map<std::string, ConnectedPointer>;

void CreateObject(Container& data);
void CountInstances(Container& data);
void DisplayTorque(Container& data, std::string ide);
std::optional<ConnectedContainer> VehicleType(Container& data);
void DiplayEngineType(Container& data);
void AverageTorque(Container& data);

#endif // FUNCTIONALITIES_H