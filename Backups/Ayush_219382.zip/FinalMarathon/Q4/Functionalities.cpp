#include "Functionalities.h"

std::mutex mt;

//Creating the object
void CreateObject(Container &data)
{
    std::lock_guard<std::mutex> lg(mt);

    data.emplace("12C", std::make_shared<ConnectedVehicle>("12C", "Automatic", SoftwareType::ADAPTIVE_AUTOSAR, NormCategory::BS6_IN, std::make_shared<Engine>(EngineType::EV, 120, 50)));

    data.emplace("13C", std::make_shared<ConnectedVehicle>("13C", "Semi", SoftwareType::ADAPTIVE_AUTOSAR, NormCategory::BS6_IN, std::make_shared<Engine>(EngineType::EV, 120, 50)));

    data.emplace("14C", std::make_shared<ConnectedVehicle>("14C", "Automatic", SoftwareType::CLASSIC_AUTOSAR, NormCategory::BS6_IN, std::make_shared<Engine>(EngineType::EV, 120, 50)));

    data.emplace("15C", std::make_shared<ConnectedVehicle>("15C", "Semi", SoftwareType::ADAPTIVE_AUTOSAR, NormCategory::BS6_IN, std::make_shared<Engine>(EngineType::EV, 120, 50)));
}

//Counting the INstances
void CountInstances(Container &data)
{
    if(data.empty()){
        throw EmptyContainerException("Data is empty");
    }
    std::lock_guard<std::mutex> lg(mt);
    int count = 0;
    count = std::count_if(
        data.begin(),
        data.end(),
        [](const PairType &p)
        {
            return p.second->vehicleEngine()->engineType() == EngineType::IC;
        });
    std::cout << "Number of Engine with eingine type IC  is: " << count << std::endl;
}

//Displaying the torque
void DisplayTorque(Container &data, std::string ide)
{
    if(data.empty()){
        throw EmptyContainerException("Data is empty");
    }
    std::lock_guard<std::mutex> lg(mt);
    auto itr = std::find_if(
        data.begin(),
        data.end(),
        [&](const PairType &p)
        {
            return p.first == ide;
        });
    if(itr==data.end()){
        std::cout<<"Data not found"<<std::endl;
    }
    else{
        std::cout<<"Engine torque founded: "<<(*itr).second->vehicleEngine()->engineTorque()<<std::endl;
    }
}


//Cheking the vehicle type
std::optional<ConnectedContainer> VehicleType(Container &data)
{
    if(data.empty()){
        throw EmptyContainerException("Data is empty");
    }
    std::lock_guard<std::mutex> lg(mt);
    ConnectedContainer ans;
    std::count_if(
        data.begin(),
        data.end(),
        [&](const PairType& p){
            if(p.second->vehicleSoftwareType()==SoftwareType::ADAPTIVE_AUTOSAR){
                ans.push_back(p.second);
            }
            return p.second->vehicleSoftwareType()==SoftwareType::ADAPTIVE_AUTOSAR;
        }
    );
    if(ans.empty()){
        return std::nullopt;
    }
    return ConnectedContainer();
}

//Displaing the engine toruqe
void DiplayEngineType(Container &data)
{
    if(data.empty()){
        throw EmptyContainerException("Data is empty");
    }
    std::lock_guard<std::mutex> lg(mt);
    std::cout<<"EV type available in the Engine? "<<std::boolalpha<<std::any_of(
        data.begin(),
        data.end(),
        [](const PairType& p){
            return p.second->vehicleEngine()->engineType()==EngineType::EV;
        }
    )<<std::endl;

}

//Getting the average toque
void AverageTorque(Container &data)
{
    if(data.empty()){
        throw EmptyContainerException("Data is empty");
    }
    std::lock_guard<std::mutex> lg(mt);
    float avg = 0.0f;
    int c=0;
    avg = std::accumulate(
        data.begin(),
        data.end(),
        0.0f,
        [&](float count, const PairType&  p){
            c++;
            return count+p.second->vehicleEngine()->engineTorque();
        }
    );
    std::cout<<"Average count is : "<<avg/c;
}
