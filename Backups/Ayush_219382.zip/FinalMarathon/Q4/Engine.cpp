#include "Engine.h"
std::ostream &operator<<(std::ostream &os, const Engine &rhs) {
    os << "_engine_type: ";
    if(rhs._engine_type == EngineType::IC) os<<"IC ";
    else os<<"EV ";
    os << " _engine_hourse_power: " << rhs._engine_hourse_power
       << " _engine_torque: " << rhs._engine_torque;
    return os;
}

Engine::Engine(EngineType engine_type, int engine_hourse_power, float engine_torque)
        : _engine_type{engine_type}, _engine_hourse_power{engine_hourse_power}, _engine_torque{engine_torque} {}