#ifndef NORMCATEGORY_H
#define NORMCATEGORY_H

enum class NormCategory{
    BS6_IN,
    EU, 
    US, 
    GB
};

#endif // NORMCATEGORY_H
