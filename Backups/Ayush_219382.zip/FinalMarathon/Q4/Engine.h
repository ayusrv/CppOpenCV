#ifndef ENGINE_H
#define ENGINE_H

#include <iostream>
#include "EngineType.h"

class Engine
{
private:
    EngineType _engine_type;
    int _engine_hourse_power;
    float _engine_torque;
public:
    Engine()=default;
    Engine(const Engine &)=delete;
    Engine(Engine && )=delete;
    Engine & operator=(const Engine & )=delete;
    Engine &operator=(Engine &&)=delete;
    ~Engine()=default;
    Engine(EngineType engine_type, int engine_hourse_power, float engine_torque);

    EngineType engineType() const { return _engine_type; }
    void setEngineType(const EngineType &engine_type) { _engine_type = engine_type; }

    int engineHoursePower() const { return _engine_hourse_power; }
    void setEngineHoursePower(int engine_hourse_power) { _engine_hourse_power = engine_hourse_power; }

    float engineTorque() const { return _engine_torque; }
    void setEngineTorque(float engine_torque) { _engine_torque = engine_torque; }

    friend std::ostream &operator<<(std::ostream &os, const Engine &rhs);
};

#endif // ENGINE_H
