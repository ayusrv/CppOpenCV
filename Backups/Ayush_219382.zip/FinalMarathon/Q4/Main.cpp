#include "Functionalities.h"
#include <array>
#include <thread>

int main()
{
    Container data;
    std::array<std::thread, 6> tArr;
    try
    {
        tArr[0] = std::thread(CreateObject, std::ref(data));
        if (tArr[0].joinable())
        {
            tArr[0].join();
        }
        tArr[1] = std::thread(CountInstances, std::ref(data));
        if (tArr[1].joinable())
        {
            tArr[1].join();
        }
        tArr[2] = std::thread(DisplayTorque, std::ref(data), "12C");
        if (tArr[2].joinable())
        {
            tArr[2].join();
        }
        tArr[3] = std::thread(VehicleType, std::ref(data));
        if (tArr[3].joinable())
        {
            tArr[3].join();
        }
        tArr[4] = std::thread(DiplayEngineType, std::ref(data));
        if (tArr[4].joinable())
        {
            tArr[4].join();
        }
        tArr[5] = std::thread(AverageTorque, std::ref(data));
        if (tArr[5].joinable())
        {
            tArr[5].join();
        }
    }
    catch (EmptyContainerException &ex)
    {
        std::cout << ex.what();
    }
}
