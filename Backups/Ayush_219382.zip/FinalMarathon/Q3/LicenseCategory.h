#ifndef LICENSECATEGORY_H
#define LICENSECATEGORY_H

enum class LicenseCategory{
    LEARNING, 
    PERMANENT
};

#endif // LICENSECATEGORY_H
