#include "TransportVehicle.h"
std::ostream &operator<<(std::ostream &os, const TransportVehicle &rhs) {
    os << "_vehicle_registration_number: " << rhs._vehicle_registration_number
       << " _vehicle_brand: " << rhs._vehicle_brand
       << " _vehicle_price: " << rhs._vehicle_price
       << " _license_category: ";
       if(rhs._license_category==LICENSECATEGORYTRANSPORT::HVM) os<<"HVM ";
       if(rhs._license_category==LICENSECATEGORYTRANSPORT::HVM_STATE) os<<"HVM State ";
    os << " _load_carrying_capacity: " << rhs._load_carrying_capacity;
    return os;
}

TransportVehicle::TransportVehicle(std::string vehicle_registration_number, std::string vehicle_brand, float vehicle_price, LICENSECATEGORYTRANSPORT license_category, float load_carrying_capacity)
        : _vehicle_registration_number{vehicle_registration_number}, _vehicle_brand{vehicle_brand}, _vehicle_price{vehicle_price}, _license_category{license_category}, _load_carrying_capacity{load_carrying_capacity} {}