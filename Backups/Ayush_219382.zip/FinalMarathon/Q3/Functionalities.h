#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <variant>
#include <vector>
#include <algorithm>
#include <numeric>
#include <memory>
#include <optional>
#include <future>
#include <thread>
#include <mutex>
#include <list>

#include "PrivateVehicle.h"
#include "TransportVehicle.h"
#include "EmptyContainerException.h"
#include "SizeNotValid.h"

using PrivateVehiclePointer = std::shared_ptr<PrivateVehicle>;
using TransportVehiclePointer = std::shared_ptr<TransportVehicle>;
using VType = std::variant<PrivateVehiclePointer, TransportVehiclePointer>;
using Conatiner = std::list<VType>;
using TransportVehicleContainer = std::vector<TransportVehiclePointer>;
using PrivateVehicleContainer = std::vector<PrivateVehiclePointer>;
using LicenseCategoryContainer = std::vector<LICENSECATEGORYTRANSPORT>;

void CreateObjects(Conatiner& data);
void TransportVehicleLicense(Conatiner& data);
std::optional<float> AveragePrice(Conatiner& data);
void DisplayPrice(Conatiner& data, std::future<int>& n);
bool SameCategory(Conatiner& data); 

#endif // FUNCTIONALITIES_H