#include "PrivateVehicle.h"
std::ostream &operator<<(std::ostream &os, const PrivateVehicle &rhs) {
    os << "_vehicle_registration_number: " << rhs._vehicle_registration_number
       << " _vehicle_brand: " << rhs._vehicle_brand
       << " _vehicle_price: " << rhs._vehicle_price
       << " _license_category: ";
       if(rhs._license_category==LicenseCategory::LEARNING) os<<"Learning ";
       if(rhs._license_category==LicenseCategory::PERMANENT) os<<"Permanent ";
    os << " _seat_count: " << rhs._seat_count;
    return os;
}

PrivateVehicle::PrivateVehicle(std::string vehicle_registration_number, std::string vehicle_brand, float vehicle_price, LicenseCategory license_category, unsigned int seat_count)
            : _vehicle_registration_number{vehicle_registration_number}, _vehicle_brand{vehicle_brand}, _vehicle_price{vehicle_price}, _license_category{license_category}, _seat_count{seat_count} {}