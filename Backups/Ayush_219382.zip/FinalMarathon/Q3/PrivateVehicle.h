#ifndef PRIVATEVEHICLE_H
#define PRIVATEVEHICLE_H

#include <iostream>
#include "LicenseCategory.h"

class PrivateVehicle
{
private:
    std::string _vehicle_registration_number;
    std::string _vehicle_brand;
    float _vehicle_price;
    LicenseCategory _license_category;
    unsigned int _seat_count;

public:
    PrivateVehicle()=default;
    PrivateVehicle(const PrivateVehicle &)=delete; //Disable copy constructor
    PrivateVehicle(PrivateVehicle && )=delete; //Disabled move constructor
    PrivateVehicle & operator=(const PrivateVehicle & )=delete; //Disable copy constructor
    PrivateVehicle &operator=(PrivateVehicle &&)=delete;  //Disabled move constructor
    ~PrivateVehicle()=default;
    PrivateVehicle(std::string vehicle_registration_number, std::string vehicle_brand, float vehicle_price, LicenseCategory license_category, unsigned int seat_count);

    std::string vehicleRegistrationNumber() const { return _vehicle_registration_number; }
    void setVehicleRegistrationNumber(const std::string &vehicle_registration_number) { _vehicle_registration_number = vehicle_registration_number; }

    std::string vehicleBrand() const { return _vehicle_brand; }
    void setVehicleBrand(const std::string &vehicle_brand) { _vehicle_brand = vehicle_brand; }

    float vehiclePrice() const { return _vehicle_price; }
    void setVehiclePrice(float vehicle_price) { _vehicle_price = vehicle_price; }

    LicenseCategory licenseCategory() const { return _license_category; }
    void setLicenseCategory(const LicenseCategory &license_category) { _license_category = license_category; }

    unsigned int seatCount() const { return _seat_count; }
    void setSeatCount(unsigned int seat_count) { _seat_count = seat_count; }

    friend std::ostream &operator<<(std::ostream &os, const PrivateVehicle &rhs);
};

#endif // PRIVATEVEHICLE_H
