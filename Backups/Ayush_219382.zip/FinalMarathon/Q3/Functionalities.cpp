#include "Functionalities.h"
std::mutex mat;
// Creating the data
void CreateObjects(Conatiner &data)
{
    data.push_back(std::make_shared<PrivateVehicle>("JH012", "BMW", 6000, LicenseCategory::PERMANENT, 12));
    data.push_back(std::make_shared<PrivateVehicle>("MH012", "Dodeg", 3600, LicenseCategory::LEARNING, 12));
    data.push_back(std::make_shared<TransportVehicle>("MP012", "Honda", 2400, LICENSECATEGORYTRANSPORT::HVM, 14.0f));
    data.push_back(std::make_shared<TransportVehicle>("PB012", "Renult", 1200, LICENSECATEGORYTRANSPORT::HVM_STATE, 15.0f));
}

// Returning the LicenseCategoryContainer of the transport vehicle
void TransportVehicleLicense(Conatiner &data)
{
    std::lock_guard<std::mutex> lg(mat);

    for(VType v : data)
    {
        if(std::holds_alternative<TransportVehiclePointer> (v)){
            TransportVehiclePointer tp = std::get<TransportVehiclePointer>(v);
            if (tp->licenseCategory() == LICENSECATEGORYTRANSPORT::HVM)
                std::cout << "HVM ";
            if (tp->licenseCategory() == LICENSECATEGORYTRANSPORT::HVM_STATE)
                std::cout << "HVM State ";
            
        }
    }
    std::cout<<std::endl;

}

// Printing the average price of the data
std::optional<float> AveragePrice(Conatiner &data)
{
    std::lock_guard<std::mutex> lg(mat);
    int count = 0;
    bool checkVel = false;
    // taking the sum in the answer
    float ans = std::accumulate(
        data.begin(),
        data.end(),
        0.0f,
        [&](float a, const VType &v)
        {
            // float ans = 0;

            // checking the condition that the value holds the privatevehiclepointer or not
            if (std::holds_alternative<PrivateVehiclePointer>(v))
            {
                PrivateVehiclePointer pv = std::get<PrivateVehiclePointer>(v);
                count++;
                checkVel = true;
                return a + pv->vehiclePrice();
            }
        });
    
    if(!checkVel){
        return std::nullopt;
    }

    return ans/count;
}

void DisplayPrice(Conatiner &data, std::future<int>& n)
{
    std::lock_guard<std::mutex> lg(mat);
    // Cheing if the data is empty or not
    if (data.empty())
    {
        throw EmptyContainerException("Data is empty", std::future_errc::no_state);
    }
    int val = n.get();

    // Cheking the size is valid or not
    if (val <= 0 || val > data.size())
    {
        throw SizeExceeded("Size is not valid for this input");
    }

    //Displaying the data
    std::cout<<"Displaying the data: "<<std::endl;
    for (VType v : data)
    {
        if(val==0) break;
        std::visit
        (
            [&](auto &&args)
            { 
                std::cout << args->vehiclePrice() << std::endl; 
                val--;
            }, v
        );
    }
}

bool SameCategory(Conatiner &data)
{
    std::lock_guard<std::mutex> lg(mat);

    // Cheing if the data is empty or not
    if (data.empty())
    {
        throw EmptyContainerException("Data is empty", std::future_errc::no_state);
    }

    //Cheking the first category with the all of functionality
    bool val1 = std::all_of(
        data.begin(),
        data.end(),
        [](const VType& v)
        {
            bool flag = false;
            if(std::holds_alternative<PrivateVehiclePointer>(v))
            {
                PrivateVehiclePointer pv = std::get<PrivateVehiclePointer>(v);
                if(pv->licenseCategory()==LicenseCategory::LEARNING){
                    flag = true;
                }
            }
            return flag;
        }
    );

    //Cheking the second condition with all of functionality
    bool val2 = std::all_of(
        data.begin(),
        data.end(),
        [](const VType& v)
        {
            bool flag = false;
            if(std::holds_alternative<PrivateVehiclePointer>(v))
            {
                PrivateVehiclePointer pv = std::get<PrivateVehiclePointer>(v);
                if(pv->licenseCategory()==LicenseCategory::PERMANENT){
                    flag = true;
                }
            }
            return flag;
        }
    );
    return val1||val2;
}
