#ifndef TRANSPORTVEHICLE_H
#define TRANSPORTVEHICLE_H

#include <iostream>
#include "LicenseCategoryTransport.h"

class TransportVehicle
{
private:
    std::string _vehicle_registration_number;
    std::string _vehicle_brand;
    float _vehicle_price;
    LICENSECATEGORYTRANSPORT _license_category;
    float _load_carrying_capacity;
public:
    TransportVehicle()=default;
    TransportVehicle(const TransportVehicle &)=delete;
    TransportVehicle(TransportVehicle && )=delete;
    TransportVehicle & operator=(const TransportVehicle & )=delete;
    TransportVehicle &operator=(TransportVehicle &&)=delete;
    ~TransportVehicle()=default;
    TransportVehicle(std::string vehicle_registration_number, std::string vehicle_brand, float vehicle_price, LICENSECATEGORYTRANSPORT license_category, float load_carrying_capacity);

    std::string vehicleRegistrationNumber() const { return _vehicle_registration_number; }
    void setVehicleRegistrationNumber(const std::string &vehicle_registration_number) { _vehicle_registration_number = vehicle_registration_number; }

    std::string vehicleBrand() const { return _vehicle_brand; }
    void setVehicleBrand(const std::string &vehicle_brand) { _vehicle_brand = vehicle_brand; }

    float vehiclePrice() const { return _vehicle_price; }
    void setVehiclePrice(float vehicle_price) { _vehicle_price = vehicle_price; }

    LICENSECATEGORYTRANSPORT licenseCategory() const { return _license_category; }
    void setLicenseCategory(const LICENSECATEGORYTRANSPORT &license_category) { _license_category = license_category; }

    float loadCarryingCapacity() const { return _load_carrying_capacity; }
    void setLoadCarryingCapacity(float load_carrying_capacity) { _load_carrying_capacity = load_carrying_capacity; }

    friend std::ostream &operator<<(std::ostream &os, const TransportVehicle &rhs);
};

#endif // TRANSPORTVEHICLE_H
