#include "Functionalities.h"

int main()
{

    Conatiner data;

    std::promise<int> pr;

    std::future<int> ft = pr.get_future();

    int n = 3;
    pr.set_value(n);

    std::future<void> create = std::async(&CreateObjects, std::ref(data));

    std::future<void> License = std::async(&TransportVehicleLicense, std::ref(data));
    
    std::future<std::optional<float>> avg = std::async(&AveragePrice, std::ref(data));

    std::future<void> disp = std::async(&DisplayPrice, std::ref(data), std::ref(ft));

    std::future<bool> same = std::async(&SameCategory, std::ref(data));

    try
    {
        create.get();
        std::cout << "Average price of Private Vehicle is: ";
        std::optional<float> f = avg.get();
        if(f.has_value()){
            std::cout<<f.value()<<std::endl;
        }else{
            std::cout<<"No data of Private vehicle availabel"<<std::endl;
        }
        disp.get();
        std::cout<<"Data are same or not: "<<std::boolalpha<<same.get()<<std::endl;
    }
    catch (EmptyContainerException &ex)
    {
        std::cout << ex.what();
    }
    catch (SizeExceeded &ex)
    {
        std::cout << ex.what();
    }
}