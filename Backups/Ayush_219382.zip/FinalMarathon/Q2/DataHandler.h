#ifndef DataHandler_H
#define DataHandler_H

#include <array>
#include <vector>
#include <memory>
#include <iostream>
#include <algorithm>
#include <numeric>
#include <thread>
#include <mutex>

class DataHandler;

using DataHandlerPointer = std::shared_ptr<DataHandler>;
using MemberContainer = std::array<int, 5>;

class DataHandler
{
private:
    static DataHandlerPointer _solo_hero_obj;
    MemberContainer _data;
    MemberContainer _square_results;
    MemberContainer _factorial_results;
    bool _flag;
    std::mutex mt;
public:
    DataHandler(MemberContainer data, MemberContainer square_results, MemberContainer factorial_results, bool flag) : _data{data}, _square_results{square_results}, _factorial_results{factorial_results} {}

    DataHandler()=delete;          // Default constructor disabled 
    
    DataHandler(const DataHandler&)=delete;              // Copy constructor disabled
    
    DataHandler(DataHandler&&)=delete;                   // Move Constructor disabled
    
    DataHandler& operator=(const DataHandler&)=delete;      // Copy Assignment Operator diabled
    
    DataHandler& operator=(DataHandler&&)=delete;       // Move Assignment Operator disabled
    
    ~DataHandler()=default;                      // Default destructor enabled

    static DataHandlerPointer getfirstInstances(MemberContainer& data, MemberContainer& square_results, MemberContainer& factorial_results, bool flag){
        if(_solo_hero_obj){
            //return address of existing object
            return _solo_hero_obj;
        }
        else{
            _solo_hero_obj.reset(new DataHandler(data, square_results, factorial_results, flag));
            return _solo_hero_obj;
        }
    }

    MemberContainer data() const { return _data; }
    void setData(const MemberContainer &data) { _data = data; }

    MemberContainer squareResults() const { return _square_results; }
    void setSquareResults(const MemberContainer &square_results) { _square_results = square_results; }

    MemberContainer factorialResults() const { return _factorial_results; }
    void setFactorialResults(const MemberContainer &factorial_results) { _factorial_results = factorial_results; }

    bool flag() const { return _flag; }
    void setFlag(bool flag) { _flag = flag; }

    void CreateData(MemberContainer& data);

    void TakeInput(MemberContainer& data);

    void ComputeSquare();

    void ComputeFactorial();

    void AverageValue();

};



#endif // DataHandler_H