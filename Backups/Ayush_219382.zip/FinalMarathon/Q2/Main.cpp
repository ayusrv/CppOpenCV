#include "DataHandler.h"

int main()
{
    MemberContainer data;
    DataHandlerPointer obj = DataHandler::getfirstInstances(data, data, data, true);
    std::unique_ptr<DataHandler> d = std::make_unique<DataHandler>(data, data, data, true);

    //Creting the thread array
    std::array<std::thread, 4> tArr;

    //Create data
    tArr[0] = std::thread(&DataHandler::CreateData, obj, std::ref(data));
    if(tArr[0].joinable())
        tArr[0].join();

    //Computing the square
    tArr[1] = std::thread(&DataHandler::ComputeSquare, obj);
    if(tArr[1].joinable())
        tArr[1].join();

    //Computing the factorial
    tArr[2] = std::thread(&DataHandler::ComputeFactorial, obj);
    if(tArr[2].joinable())
        tArr[2].join();

    //Average value calculating
    tArr[3] = std::thread(&DataHandler::AverageValue, obj);
    if(tArr[3].joinable())
        tArr[3].join();
}