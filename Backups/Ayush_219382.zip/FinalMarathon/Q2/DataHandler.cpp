#include "DataHandler.h"

DataHandlerPointer DataHandler::_solo_hero_obj{nullptr};

//Creating the data
void DataHandler::CreateData(MemberContainer &data)
{
    std::cout << "Please Enter the data: ";
    for (int i = 0; i < data.size(); i++)
    {
        std::lock_guard<std::mutex> lg(mt);
        std::cin >> data[i];
    }

    //Calling the take input if not valid
    TakeInput(data);
}

//Calling the take input 
void DataHandler::TakeInput(MemberContainer &data)
{
    std::lock_guard<std::mutex> lg(mt);
    // checking the data is it valid or not
    bool check = std::all_of(
        data.begin(),
        data.end(),
        [](int i)
        {
            return (i <= 10 && i >= 1);
        });
    
    //if data is wrong calling the create object again
    if (!check)
    {
        std::cout << "Wrong data" << std::endl;
        CreateData(data);
    }

    //setting the data
    else
    {
        setData(data);
        std::cout << "Input taken successfully" << std::endl;
    }
}

//Calculating the square
void DataHandler::ComputeSquare()
{
    std::lock_guard<std::mutex> lg(mt);
    std::cout << "Sqaure of first 5 Odd, natural numbers that are divisible by 3: ";

    //cre
    MemberContainer _val{3, 9, 15, 21, 27};
    for (int i = 0; i < _val.size(); i++)
    {
        _val[i] = _val[i] * _val[i];
    }
    std::copy(
        _val.begin(),
        _val.end(),
        _square_results.begin());
    for (int i : _square_results)
    {
        std::cout << i << " ";
    }
    std::cout << std::endl;
}

//Calculating the factorial
void DataHandler::ComputeFactorial()
{
    for(int i=0;i<_factorial_results.size();i++){
        _factorial_results[i] = 1;
    }
    std::cout << "Factoral of the data are: ";
    std::lock_guard<std::mutex> lg(mt);
    for (int i = 0; i < _data.size(); i++)
    {
        for(int j=1;j<=_data[i];j++)
        {
            _factorial_results[i] = _factorial_results[i]*j;
        }
    }
    for (int i : _factorial_results)
    {
        std::cout << i << " ";
    }
    std::cout << std::endl;
}

//Calculating the average
void DataHandler::AverageValue()
{
    std::lock_guard<std::mutex> lg(mt);
    MemberContainer _memCont = {2, 3, 5, 7, 11};
    float avg = std::accumulate(
        _memCont.begin(),
        _memCont.end(),
        0.0f,
        [](int start_val, int i)
        {
            return i + start_val;
        });
    std::cout << "Average of first 5 prime number is: " << avg / 5 << std::endl;
}
